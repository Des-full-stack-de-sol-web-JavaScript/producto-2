export const userList = [
  {
    rol: "usuario",
    nombre: "Kevin",
    email: "kevin.gomez@gmail.com",
    password: "password123",
  },
  {
    rol: "usuario",
    nombre: "Thabata",
    email: "thabata.diaz@gmail.com",
    password: "password123",
  },
  {
    rol: "usuario",
    nombre: "Anna",
    email: "anna.ruiz@gmail.com",
    password: "password123",
  },
  {
    rol: "usuario",
    nombre: "Mar",
    email: "mar.sanchez@gmail.com",
    password: "password123",
  },
  {
    rol: "usuario",
    nombre: "Pol",
    email: "pol.valle@gmail.com",
    password: "password123",
  },
  {
    rol: "usuario",
    nombre: "Lia",
    email: "lia.martin@gmail.com",
    password: "password123",
  },
  {
    rol: "usuario",
    nombre: "Rau",
    email: "rau.perez@gmail.com",
    password: "password123",
  },
  {
    rol: "usuario",
    nombre: "Jor",
    email: "jor.fernandez@gmail.com",
    password: "password123",
  },
  {
    rol: "usuario",
    nombre: "Pol",
    email: "doplax@gmail.com",
    password: "password123",
  },
];
